wiens_displacement_const = 2.897771955*10**(-3) # m K
boltzmans_const = 1.380649*10**(-23)            # J/K
speed_light = 299792458                         # m/s
plancks_const = 6.62607015*10**(-34)            # Js